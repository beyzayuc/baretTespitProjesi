import argparse
from collections import defaultdict, deque
from pathlib import Path

import cv2
from ultralytics import YOLO


PROJECT_DIR = Path(__file__).resolve().parent.parent
HELMET_MODEL_PATH = PROJECT_DIR / "outputs" / "helmet_v1" / "weights" / "best.pt"

PERSON_CONFIDENCE = 0.55
HELMET_CONFIDENCE = 0.50
HEAD_REGION_RATIO = 0.32
DECISION_FRAMES = 15
HELMET_VOTES_REQUIRED = 10
NO_HELMET_MAX_VOTES = 3


def point_inside_box(point_x, point_y, box):
    x1, y1, x2, y2 = box
    return x1 <= point_x <= x2 and y1 <= point_y <= y2


def main():
    parser = argparse.ArgumentParser(description="Video uzerinde baret tespiti")
    parser.add_argument(
        "video",
        nargs="?",
        default="test_videos/baretli_iki_calisan.mp4",
        help="Proje klasorune gore video yolu",
    )
    args = parser.parse_args()

    video_path = Path(args.video)
    if not video_path.is_absolute():
        video_path = PROJECT_DIR / video_path
    output_path = PROJECT_DIR / "outputs" / f"{video_path.stem}_sonuc.mp4"

    if not video_path.exists():
        raise FileNotFoundError(f"Video bulunamadi: {video_path}")
    if not HELMET_MODEL_PATH.exists():
        raise FileNotFoundError(f"Baret modeli bulunamadi: {HELMET_MODEL_PATH}")

    print("Modeller yukleniyor...")
    person_model = YOLO("yolov8n.pt")
    helmet_model = YOLO(str(HELMET_MODEL_PATH))

    video = cv2.VideoCapture(str(video_path))
    if not video.isOpened():
        raise RuntimeError(f"Video acilamadi: {video_path}")

    width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = video.get(cv2.CAP_PROP_FPS) or 25.0

    output_path.parent.mkdir(parents=True, exist_ok=True)
    writer = cv2.VideoWriter(
        str(output_path),
        cv2.VideoWriter_fourcc(*"mp4v"),
        fps,
        (width, height),
    )

    print("Video isleniyor. Erken cikmak icin Q tusuna basin.")
    helmet_history = defaultdict(lambda: deque(maxlen=DECISION_FRAMES))

    while True:
        success, frame = video.read()
        if not success:
            break

        person_result = person_model.track(
            frame,
            persist=True,
            classes=[0],
            conf=PERSON_CONFIDENCE,
            imgsz=320,
            tracker="bytetrack.yaml",
            verbose=False,
        )[0]

        helmet_result = helmet_model.predict(
            frame,
            classes=[0, 1],
            conf=HELMET_CONFIDENCE,
            imgsz=320,
            verbose=False,
        )[0]

        helmets = []
        exposed_heads = []
        if helmet_result.boxes is not None:
            detected_boxes = helmet_result.boxes.xyxy.cpu().tolist()
            detected_classes = helmet_result.boxes.cls.int().cpu().tolist()
            for detected_box, detected_class in zip(detected_boxes, detected_classes):
                box = tuple(map(int, detected_box))
                if detected_class == 0:
                    exposed_heads.append(box)
                elif detected_class == 1:
                    helmets.append(box)

        if person_result.boxes is not None:
            person_boxes = person_result.boxes.xyxy.cpu().tolist()
            track_ids = (
                person_result.boxes.id.int().cpu().tolist()
                if person_result.boxes.id is not None
                else [-1] * len(person_boxes)
            )

            for person_box, track_id in zip(person_boxes, track_ids):
                px1, py1, px2, py2 = map(int, person_box)
                head_bottom = py1 + int((py2 - py1) * HEAD_REGION_RATIO)
                head_region = (px1, py1, px2, head_bottom)

                has_helmet = False
                for hx1, hy1, hx2, hy2 in helmets:
                    helmet_center_x = (hx1 + hx2) // 2
                    helmet_center_y = (hy1 + hy2) // 2
                    if point_inside_box(helmet_center_x, helmet_center_y, head_region):
                        has_helmet = True
                        break

                has_exposed_head = False
                for hx1, hy1, hx2, hy2 in exposed_heads:
                    head_center_x = (hx1 + hx2) // 2
                    head_center_y = (hy1 + hy2) // 2
                    if point_inside_box(head_center_x, head_center_y, head_region):
                        has_exposed_head = True
                        break

                # Veri setindeki "head" sinifi acik/baretsiz basi temsil eder.
                # Ayni bolgede iki sinif birden cikarsa head sonucuna oncelik verilir.
                if has_exposed_head:
                    helmet_history[track_id].append(False)
                elif has_helmet:
                    helmet_history[track_id].append(True)

                votes = sum(helmet_history[track_id])
                observation_count = len(helmet_history[track_id])

                if not has_exposed_head and not has_helmet:
                    color = (0, 215, 255)
                    label = f"GORUNTU YETERSIZ ID:{track_id}"
                elif observation_count < DECISION_FRAMES:
                    color = (0, 215, 255)
                    label = f"KONTROL EDILIYOR ID:{track_id}"
                elif votes >= HELMET_VOTES_REQUIRED:
                    color = (0, 200, 0)
                    label = f"BARETLI ID:{track_id}"
                elif votes <= NO_HELMET_MAX_VOTES:
                    color = (0, 0, 255)
                    label = f"BARETSIZ ID:{track_id}"
                else:
                    color = (0, 165, 255)
                    label = f"KARARSIZ ID:{track_id}"

                cv2.rectangle(frame, (px1, py1), (px2, py2), color, 3)
                cv2.putText(
                    frame,
                    label,
                    (px1, max(25, py1 - 10)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    color,
                    2,
                )

        writer.write(frame)
        cv2.imshow("Baret Tespit Sistemi", frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            print("Kullanici islemi durdurdu.")
            break

    video.release()
    writer.release()
    cv2.destroyAllWindows()
    print(f"Tamamlandi. Sonuc: {output_path}")


if __name__ == "__main__":
    main()
